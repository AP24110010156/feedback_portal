const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');

dotenv.config();

const seedUsers = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    
    // Clear existing users
    await User.deleteMany();

    // Insert Admin
    const adminUser = new User({
      username: 'admin',
      email: 'admin@portal.com',
      password: 'password123',
      role: 'admin'
    });

    // Insert standard User
    const standardUser = new User({
      username: 'johndoe',
      email: 'user@portal.com',
      password: 'password123',
      role: 'user'
    });

    await adminUser.save();
    await standardUser.save();

    console.log('Test users created successfully!');
    process.exit();
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

seedUsers();
