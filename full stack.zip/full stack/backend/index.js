require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const User = require('./models/User');

// Connect to database
connectDB().then(async () => {
  try {
    const usersCount = await User.countDocuments();
    if (usersCount === 0) {
      await User.create([
        { username: 'admin', email: 'admin@portal.com', password: 'password123', role: 'admin' },
        { username: 'johndoe', email: 'user@portal.com', password: 'password123', role: 'user' }
      ]);
      console.log('Test users automatically seeded into in-memory DB!');
    }
  } catch(err) { console.error('Seed error', err); }
});

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/feedback', require('./routes/feedbackRoutes'));
app.use('/api/featurerequests', require('./routes/featureRequestRoutes'));

app.get('/', (req, res) => {
  res.send('API is running...');
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
