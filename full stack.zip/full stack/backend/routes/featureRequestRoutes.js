const express = require('express');
const router = express.Router();
const {
  createFeatureRequest,
  getFeatureRequests,
  updateRequestStatus,
  upvoteRequest
} = require('../controllers/featureRequestController');
const { protect, admin } = require('../middleware/auth');

router.route('/')
  .post(protect, createFeatureRequest)
  .get(getFeatureRequests);

router.route('/:id/status')
  .put(protect, admin, updateRequestStatus);

router.route('/:id/upvote')
  .post(protect, upvoteRequest);

module.exports = router;
