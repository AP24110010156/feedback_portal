const express = require('express');
const router = express.Router();
const { createFeedback, getFeedbacks, deleteFeedback } = require('../controllers/feedbackController');
const { protect, admin } = require('../middleware/auth');

router.route('/')
  .post(protect, createFeedback)
  .get(getFeedbacks);

router.route('/:id')
  .delete(protect, admin, deleteFeedback);

module.exports = router;
