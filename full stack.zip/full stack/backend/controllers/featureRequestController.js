const FeatureRequest = require('../models/FeatureRequest');
const Vote = require('../models/Vote');

const createFeatureRequest = async (req, res) => {
  const { title, description } = req.body;

  try {
    const request = new FeatureRequest({
      title,
      description,
      createdBy: req.user._id
    });

    const createdRequest = await request.save();
    res.status(201).json(createdRequest);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getFeatureRequests = async (req, res) => {
  try {
    const requests = await FeatureRequest.find().populate('createdBy', 'username');
    res.json(requests);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateRequestStatus = async (req, res) => {
  const { status } = req.body;

  try {
    const request = await FeatureRequest.findById(req.params.id);

    if (request) {
      request.status = status;
      const updatedRequest = await request.save();
      res.json(updatedRequest);
    } else {
      res.status(404).json({ message: 'Feature request not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const upvoteRequest = async (req, res) => {
  try {
    const requestId = req.params.id;
    const userId = req.user._id;

    const request = await FeatureRequest.findById(requestId);
    if (!request) {
      return res.status(404).json({ message: 'Feature request not found' });
    }

    const existingVote = await Vote.findOne({ requestId, userId });

    if (existingVote) {
      return res.status(400).json({ message: 'You have already voted for this request' });
    }

    await Vote.create({ requestId, userId });
    request.votes += 1;
    await request.save();

    res.json({ message: 'Upvoted successfully', votes: request.votes });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createFeatureRequest, getFeatureRequests, updateRequestStatus, upvoteRequest };
