const mongoose = require('mongoose');

const featureRequestSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  votes: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['Pending', 'Under Review', 'Implemented'],
    default: 'Pending'
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, { timestamps: true });

module.exports = mongoose.model('FeatureRequest', featureRequestSchema);
