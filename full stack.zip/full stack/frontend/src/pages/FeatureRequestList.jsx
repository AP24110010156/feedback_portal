import React, { useState, useEffect, useContext } from 'react';
import api from '../api/axios';
import { AuthContext } from '../context/AuthContext';
import { ThumbsUp } from 'lucide-react';

const FeatureRequestList = () => {
  const [requests, setRequests] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(true);
  const { user } = useContext(AuthContext);

  const fetchRequests = async () => {
    try {
      const response = await api.get('/featurerequests');
      setRequests(response.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/featurerequests', { title, description });
      setTitle('');
      setDescription('');
      fetchRequests();
    } catch (error) {
      console.error('Error submitting feature request', error);
    }
  };

  const handleUpvote = async (id) => {
    try {
      await api.post(`/featurerequests/${id}/upvote`);
      fetchRequests();
    } catch (error) {
      alert(error.response?.data?.message || 'Error upvoting');
    }
  };

  const handleStatusUpdate = async (id, status) => {
    try {
      await api.put(`/featurerequests/${id}/status`, { status });
      fetchRequests();
    } catch (error) {
      console.error('Error updating status', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Implemented': return 'bg-green-100 text-green-800';
      case 'Under Review': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h2 className="text-2xl font-bold mb-4">Request a Feature</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full border rounded p-2 focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full border rounded p-2 focus:ring-2 focus:ring-blue-500 outline-none h-24"
              required
            ></textarea>
          </div>
          <button
            type="submit"
            className="bg-blue-600 text-white font-medium py-2 px-6 rounded hover:bg-blue-700 transition"
          >
            Submit Request
          </button>
        </form>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h2 className="text-2xl font-bold mb-4">Feature Requests</h2>
        {loading ? (
          <p>Loading...</p>
        ) : requests.length === 0 ? (
          <p className="text-gray-500">No feature requests yet.</p>
        ) : (
          <div className="space-y-4">
            {requests.map((req) => (
              <div key={req._id} className="border p-4 rounded bg-gray-50 flex flex-col md:flex-row gap-4 justify-between">
                <div className="flex-grow">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-lg">{req.title}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded ${getStatusColor(req.status)}`}>
                      {req.status}
                    </span>
                  </div>
                  <p className="text-gray-700 text-sm mb-2">{req.description}</p>
                  <p className="text-xs text-gray-500">
                    By {req.createdBy?.username} on {new Date(req.createdAt).toLocaleDateString()}
                  </p>

                  {user?.role === 'admin' && (
                    <div className="mt-3 flex items-center gap-2 text-sm">
                      <span className="text-gray-600">Update Status:</span>
                      <select
                        className="border rounded p-1"
                        value={req.status}
                        onChange={(e) => handleStatusUpdate(req._id, e.target.value)}
                      >
                        <option value="Pending">Pending</option>
                        <option value="Under Review">Under Review</option>
                        <option value="Implemented">Implemented</option>
                      </select>
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-center justify-center bg-white p-3 rounded border md:min-w-[80px]">
                  <button
                    onClick={() => handleUpvote(req._id)}
                    className="p-1 rounded text-gray-500 hover:text-blue-600 hover:bg-blue-50 transition"
                    title="Upvote"
                  >
                    <ThumbsUp size={24} />
                  </button>
                  <span className="font-bold text-lg mt-1">{req.votes}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FeatureRequestList;
