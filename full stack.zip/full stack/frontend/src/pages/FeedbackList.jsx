import React, { useState, useEffect, useContext } from 'react';
import api from '../api/axios';
import { AuthContext } from '../context/AuthContext';

const FeedbackList = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('General');
  const [loading, setLoading] = useState(true);
  const { user } = useContext(AuthContext);

  const fetchFeedbacks = async () => {
    try {
      const response = await api.get('/feedback');
      setFeedbacks(response.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/feedback', { title, description, category });
      setTitle('');
      setDescription('');
      fetchFeedbacks();
    } catch (error) {
      console.error('Error submitting feedback', error);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this feedback?')) {
      try {
        await api.delete(`/feedback/${id}`);
        fetchFeedbacks();
      } catch (error) {
        console.error('Error deleting feedback', error);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h2 className="text-2xl font-bold mb-4">Submit Feedback</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full border rounded p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full border rounded p-2 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="General">General</option>
                <option value="Bug">Bug Report</option>
                <option value="UI/UX">UI/UX</option>
                <option value="Service">Service</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full border rounded p-2 focus:ring-2 focus:ring-blue-500 outline-none h-24"
              required
            ></textarea>
          </div>
          <button
            type="submit"
            className="bg-blue-600 text-white font-medium py-2 px-6 rounded hover:bg-blue-700 transition"
          >
            Submit Feedback
          </button>
        </form>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h2 className="text-2xl font-bold mb-4">Recent Feedback</h2>
        {loading ? (
          <p>Loading...</p>
        ) : feedbacks.length === 0 ? (
          <p className="text-gray-500">No feedback submitted yet.</p>
        ) : (
          <div className="space-y-4">
            {feedbacks.map((fb) => (
              <div key={fb._id} className="border p-4 rounded bg-gray-50 flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-lg">{fb.title}</h3>
                    <span className="text-xs bg-gray-200 px-2 py-0.5 rounded text-gray-600">
                      {fb.category}
                    </span>
                  </div>
                  <p className="text-gray-700 text-sm mb-2">{fb.description}</p>
                  <p className="text-xs text-gray-500">
                    By {fb.createdBy?.username} on {new Date(fb.createdAt).toLocaleDateString()}
                  </p>
                </div>
                {user?.role === 'admin' && (
                  <button
                    onClick={() => handleDelete(fb._id)}
                    className="text-red-500 text-sm hover:underline"
                  >
                    Delete
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FeedbackList;
