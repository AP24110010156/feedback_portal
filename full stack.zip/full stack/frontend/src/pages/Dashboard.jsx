import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { MessageSquarePlus, Lightbulb } from 'lucide-react';

const Dashboard = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-8 rounded-lg shadow-sm border">
        <h1 className="text-3xl font-bold mb-2">Welcome, {user?.username}!</h1>
        <p className="text-gray-600">
          This is the Customer Feedback & Feature Request Portal. 
          Use the quick links below to navigate.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-blue-100 p-3 rounded-full text-blue-600">
              <MessageSquarePlus size={24} />
            </div>
            <h2 className="text-xl font-semibold">Feedback</h2>
          </div>
          <p className="text-gray-600 mb-4 h-12">
            Share your thoughts on our products and services. Let us know what you think!
          </p>
          <Link
            to="/feedback"
            className="inline-block bg-gray-100 font-medium px-4 py-2 rounded text-gray-800 hover:bg-gray-200"
          >
            Go to Feedback
          </Link>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-yellow-100 p-3 rounded-full text-yellow-600">
              <Lightbulb size={24} />
            </div>
            <h2 className="text-xl font-semibold">Feature Requests</h2>
          </div>
          <p className="text-gray-600 mb-4 h-12">
            Have an idea to improve our platform? Suggest it here and vote on others.
          </p>
          <Link
            to="/features"
            className="inline-block bg-gray-100 font-medium px-4 py-2 rounded text-gray-800 hover:bg-gray-200"
          >
            Go to Features
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
