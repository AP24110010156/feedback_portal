import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { LogOut, LayoutDashboard, MessageSquarePlus, Lightbulb } from 'lucide-react';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="text-xl font-bold text-blue-600 flex items-center gap-2">
            Portal
          </Link>

          {user ? (
            <div className="flex items-center space-x-6">
              <Link to="/" className="text-gray-600 hover:text-blue-600 flex items-center gap-1">
                <LayoutDashboard size={18} /> Dashboard
              </Link>
              <Link to="/feedback" className="text-gray-600 hover:text-blue-600 flex items-center gap-1">
                <MessageSquarePlus size={18} /> Feedback
              </Link>
              <Link to="/features" className="text-gray-600 hover:text-blue-600 flex items-center gap-1">
                <Lightbulb size={18} /> Features
              </Link>
              <div className="border-l pl-6 flex items-center space-x-4">
                <span className="text-sm font-medium text-gray-800">
                  {user.username} {user.role === 'admin' ? '(Admin)' : ''}
                </span>
                <button
                  onClick={handleLogout}
                  className="text-red-500 hover:text-red-700 flex items-center gap-1"
                >
                  <LogOut size={18} /> Logout
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <Link to="/login" className="text-gray-600 hover:text-blue-600">
                Login
              </Link>
              <Link
                to="/register"
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
              >
                Register
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
